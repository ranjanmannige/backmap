var DOCUMENTATION_OPTIONS = {
    URL_ROOT: '',
    VERSION: 'v0.2.4+3.gbf4c9ed.dirty',
    LANGUAGE: 'None',
    COLLAPSE_INDEX: false,
    FILE_SUFFIX: '.html',
    HAS_SOURCE: true,
    SOURCELINK_SUFFIX: '.txt'
};