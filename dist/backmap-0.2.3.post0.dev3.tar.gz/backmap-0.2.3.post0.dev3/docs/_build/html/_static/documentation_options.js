var DOCUMENTATION_OPTIONS = {
    URL_ROOT: '',
    VERSION: 'v0.2.3+3.g96bff48.dirty',
    LANGUAGE: 'None',
    COLLAPSE_INDEX: false,
    FILE_SUFFIX: '.html',
    HAS_SOURCE: true,
    SOURCELINK_SUFFIX: '.txt'
};