var DOCUMENTATION_OPTIONS = {
    URL_ROOT: '',
    VERSION: 'v0.1.0+0.gf3141b9.dirty',
    LANGUAGE: 'None',
    COLLAPSE_INDEX: false,
    FILE_SUFFIX: '.html',
    HAS_SOURCE: true,
    SOURCELINK_SUFFIX: '.txt'
};