var DOCUMENTATION_OPTIONS = {
    URL_ROOT: '',
    VERSION: 'v0.0.3+4.g0ce186a.dirty',
    LANGUAGE: 'None',
    COLLAPSE_INDEX: false,
    FILE_SUFFIX: '.html',
    HAS_SOURCE: true,
    SOURCELINK_SUFFIX: '.txt'
};